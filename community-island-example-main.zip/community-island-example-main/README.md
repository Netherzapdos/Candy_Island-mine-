# Test Island Example

Welcome to the first every Community Island!

Custom Scene file is found at `public/Scene.js`

Custom Map file at `public/map.json`
